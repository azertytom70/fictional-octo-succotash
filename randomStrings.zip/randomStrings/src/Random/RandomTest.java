
package Random;


public class RandomTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            RandomProbeer r = new  RandomProbeer();
           // r.genereerGetal();
          // r.genereerGetaltotGetal(50);
         /*  for (int i = 0; i < 10; i++) {
           r.genereerGetalMinMax(30, 70);
        }*/
            r.genereerGetalAantal(30, 70,3);
    }
    
}
