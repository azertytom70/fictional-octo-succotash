
package Random;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author tomge
 */
public class RandomProbeer {

    public RandomProbeer() {
    }
     public void genereerGetal(){
        Random random =  new Random();
        //genereert een getal tssen 0 en 9
        int getal = random.nextInt(10);
         System.out.println("getal = "+getal);
        }
        public void genereerGetaltotGetal(int getal){
        Random random =  new Random();
        //genereert een getal tssen 0 en 9
        int getal1 = random.nextInt(getal)+1;
         System.out.println("getal = "+getal1);
        }
                public void genereerGetalMinMax(int min, int max){
        Random random =  new Random();
        //genereert een getal tssen 0 en 9
        int getalx = random.nextInt(max-min+1)+min;
         System.out.println("getal = "+getalx);
        }
                
         public void genereerGetalAantal(int min, int max, int aantal){
        Random random =  new Random();
        int getallen[]=new int[aantal];
         int index =0;
        //plaats in deze array alle uniek gegnereerde getallen
        while(index<aantal){
        int getalx = random.nextInt(max-min+1)+min;
       
        boolean gevonden = false;
             for (int i = 0; i < index && gevonden ==false; i++) {
                 if(getalx==getallen[i]){
                     gevonden = true;
                 }  
             }
             if (gevonden == false) {
                 getallen[index]=getalx;   
                 index++;
             }

            System.out.println("getal = "+getalx);
          }
         }
         
         public void genereerAantal2(int min, int max, int aantal){
             ArrayList<Integer>lijst = new ArrayList<>();
              Random random =  new Random();
              int getalx = random.nextInt(max-min+1)+min;
              int teller=0;
              while(teller<aantal)
              if(!lijst.contains(getalx))
              {
                  lijst.add(getalx);
                  teller++;
              }
              for (Integer getal1 : lijst) {
                System.out.println("getal = "+getalx);
             }
              
         }
}
