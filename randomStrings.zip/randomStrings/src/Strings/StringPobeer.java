
package Strings;

import java.util.Arrays;

/**
 *
 * @author tomge
 */
public class StringPobeer {

    public StringPobeer() {
    }
    
   /* public void printLowerUpper(String woord){
        System.out.println(woord.toLowerCase());
        System.out.println(woord.toUpperCase());
    }*/
    
    public String SchrapLeestekensSpaties(String zin){
        return zin.replaceAll("[ , ; .]", ""); // "[  zorg dat er geen spatie zit tussen " en [
    }
    
    public void printKlinkersSpatie(String woord){
        System.out.println(woord.replaceAll("[oaieOAIE]", " ")); 
    }
    
    public boolean printPalindroom(String woord){
        int lengte = woord.length();
        boolean check = true;
        int karakter =0;
        while(lengte-1>karakter){
            if(woord.charAt(karakter)==woord.charAt(lengte-1)){
                check = true;
                karakter++;
                lengte--;
            }
            else{
                check = false;
            }
        }
          return check;
    }
    public void  printWoorden(String woord){
        String lijst[]=woord.split(" ");
        for (String s:lijst) {
            System.out.println(s);
        }
    }
    public void printGemiddeldeAantalLetters(String [ ]woorden){
        int lengtel =woorden.length;
        int som=0, letters=0;
        for (String s:woorden) {
            int lengtew =s.length();
            som=som+lengtew;
        }
       letters= som/lengtel;
        System.out.println("het aantal is "+letters);
    }
    
    public void printAlfa(String [] woord){
        Arrays.sort(woord);
        for(String s : woord) {
            System.out.println(s);
        }
    }
    public void printSom(String getal){
        int som=0;
        for (int i = 0; i < getal.length(); i++) {
          som = som +Integer.parseInt(getal.substring(i, i+1));
        }
        System.out.println("som van "+getal+  " is "+som);
    }
    public void tellen(int getal){
        int som =0;
       int  getal2=getal;
        while(getal2>0){
            int rest = getal%10;
            som+=rest;
            getal2=getal2/10;
        }
        System.out.println("som = "+som);
    }
}
