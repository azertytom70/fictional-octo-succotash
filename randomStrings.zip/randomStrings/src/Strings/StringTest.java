/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Strings;

/**
 *
 * @author tomge
 */
public class StringTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StringPobeer p = new StringPobeer();
        //p.printLowerUpper("woord");
        System.out.println(p.SchrapLeestekensSpaties(";tom ,tom.tom")); 
        p.printKlinkersSpatie("woordaaaatom");
        p.printPalindroom("lepel");
        p.printWoorden("het regent katten");
        String lijst[]={"woord"," is","kapoen","programma"};
        p.printGemiddeldeAantalLetters(lijst);
        String alfa[]={"abord","is","kapoen","programma"};
        p.printAlfa(alfa);
        p.printSom("1234");
        p.tellen(1234);
    }
    
}
