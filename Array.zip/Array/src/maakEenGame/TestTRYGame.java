package maakEenGame;

import java.awt.Color;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class TestTRYGame  {
    public static void main(String[] args) {
        TryGame g = new TryGame();
        g.setVisible(true);
        
    }


    
}
