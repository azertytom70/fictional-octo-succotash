package maakEenGame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class Border extends JLabel {

    public Snake S = new Snake();
    public Timer t = null;
    public bolletjes b = new bolletjes();
    public Random r = null;
    private ArrayList<Snake> snake = new ArrayList<Snake>();

    public Border() {
        r = new Random(System.currentTimeMillis());
        addKeyListener(new KeyControl());
        setFocusable(true);
        t = new Timer(100, new TimerControl());
        t.start();
        snake.add(S);
        for (int i = 0; i < 3; i++) {
            addsnakepart();
        }
        add(b);
        add(S);        
    }

    public void rond() {
        int x = 0;
        int y = 0;
        int breedte = getWidth() - 11 - b.Circel;
        int hoogte = getHeight() - 11 - b.Circel;
        x = Math.abs(r.nextInt()) % breedte;
        y = Math.abs(r.nextInt()) % hoogte;
        x = x - x % 20;
        y = y - y % 20;
        b.setpositie(x, y);
    }

    public void addsnakepart() {
        Snake sn = snake.get(snake.size() - 1).snakebody();
        snake.add(sn);
        add(sn);
    }

    public void snakebeweegt() {
        for (int i = snake.size() - 1; i > 0; i--) {
            Snake sn = snake.get(i - 1);
            Snake s = snake.get(i);
            snake.get(i).richting();
            s.t = sn.t;
        }
        S.richting();
    }

    public boolean GameOver() {
        int kolom = 10;
        int hoogte = getHeight();
        int breede = getWidth();
        if (S.getX() <= -1) {
            
            return true;
        }
        if (S.getX() + S.vierkant >= breede + 1) {
            return true;
        }
        if (S.getY() <= -1) {
            return true;
        }
        if (S.getY() + S.vierkant >= hoogte + 1) {
            return true;
        }
        for (int i = 1; i < snake.size(); i++) {
            int x = snake.get(i).getX();
            int y = snake.get(i).getY();
            if (x == S.getX() && y == S.getY()) {
                return true;
            }
        }
        if (b.getX() == S.getX() && b.getY() == S.getY()) {
            addsnakepart();
            rond();
        }
        return false;
    }

    class KeyControl implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                if (S.t != test.rechts) {
                    S.t = test.links;
                }
            }
            if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                if (S.t != test.links) {
                    S.t = test.rechts;
                }
            }
            if (e.getKeyCode() == KeyEvent.VK_UP) {
                if (S.t != test.omlaag) {
                    S.t = test.omhoog;
                }
            }
            if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                if (S.t != test.omhoog) {
                    S.t = test.omlaag;
                }
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {

        }

    }

    class TimerControl implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            snakebeweegt();
            if (GameOver()) {
                t.stop();
            }
        }

    }

}
