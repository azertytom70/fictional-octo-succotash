/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maakEenGame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JLabel;

/**
 *
 * @author sydney
 */
public class Snake extends JLabel {

    public final int vierkant = 20;
    public int t = test.rechts;

    public Snake() {
        setBounds(100, 100, vierkant, vierkant);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        Graphics2D g2 = (Graphics2D) g;
        Rectangle2D r = new Rectangle2D.Double(1, 1, getWidth() - 2, getHeight() - 2);
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(2));
        g2.draw(r);
        g2.setColor(Color.CYAN);
        g2.fill(r);
    }
    
    public Snake snakebody(){
        Snake s = new Snake();
        int x = getX();
        int y = getY();
        s.setBounds(x, y, vierkant, vierkant);
        s.t = -t;
        s.richting();
        s.t = t;
        return s;
    }

    public void links() {
        int x = getX();
        int y = getY();
        x -= vierkant;
        setBounds(x, y, vierkant, vierkant);
    }

    public void rechts() {
        int x = getX();
        int y = getY();
        x += vierkant;
        setBounds(x, y, vierkant, vierkant);
    }

    public void omhoog() {
        int x = getX();
        int y = getY();
        y -= vierkant;
        setBounds(x, y, vierkant, vierkant);
    }

    public void omlaag() {
        int x = getX();
        int y = getY();
        y += vierkant;
        setBounds(x, y, vierkant, vierkant);
    }

    public void richting() {
        if (t == test.rechts) {
            rechts();
        } else if (t == test.links) {
            links();
        } else if (t == test.omlaag) {
            omlaag();
        } else {
            omhoog();
        }
    }



}
