package maakEenGame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.geom.Rectangle2D;
import javax.swing.JFrame;

public class TryGame extends JFrame {

    private final int breede = 610;
    private final int hoogte = 610;

    public TryGame() {
        setBounds(0,0,breede, hoogte);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Snake");
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("Snake2.png")));
        Border b = new Border();
        add(b);
    }
//    public void paint(Graphics g) {
//        super.paint(g); //To change body of generated methods, choose Tools | Templates.
//        Graphics2D g2 = (Graphics2D) g;
//        Rectangle2D test = new Rectangle2D.Double(1, 1, getWidth(),getHeight());
//        g2.setColor(Color.black);
//        g2.setStroke(new BasicStroke(2));
//        g2.fill(test);
//    }

}
