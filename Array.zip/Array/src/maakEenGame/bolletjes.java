package maakEenGame;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JLabel;

public class bolletjes extends JLabel{
    public final int Circel = 20;
    public bolletjes() {
        setBounds(100, 100, Circel, Circel);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g); //To change body of generated methods, choose Tools | Templates.
        Graphics2D g2 = (Graphics2D) g;
        Ellipse2D C = new Ellipse2D.Double(1, 1, Circel-2,Circel-2);
        g2.setColor(Color.black);
        g2.setStroke(new BasicStroke(2));
        g2.draw(C);
        g2.setColor(Color.YELLOW);
        g2.fill(C);
    }
    
    public void setpositie(int x, int y){
        setBounds(x, y, Circel, Circel);
    }

    
}
