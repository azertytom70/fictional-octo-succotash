package maakEenGame;
public interface test {
    public static final int rechts = 1;
    public static final int links = -1;
    public static final int omhoog = -2;
    public static final int omlaag = 2;
}
