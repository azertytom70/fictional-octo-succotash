package array;

public class clown {

    private String naam;
    private int schater[] = new int[365];
    // allemaal op null
    private boolean werkt[] = new boolean[7];
    // initieel ingevuld met false
    private double loon;
    private String dagenWeek[] = {"zondag", "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag"};

    public clown(String naam, double loon) {
        this.naam = naam;
        this.loon = loon;
    }

    public int[] toonHardstGelachenMeer() {
        //retutn een getal van 0 tot 364
        int meestGelachen[] = new int[365];
        int meest = schater[0];

        for (int i = 0; i < schater.length; i++) {
            if (schater[i] >= meest) {
                meest = schater[i];
            }
        }
        //in meest staat het hoogste getal
        int j = 0;
        for (int i = 0; i < schater.length; i++) {
            if (schater[i] == meest) {
                meestGelachen[j] = i;
                System.out.println("plaats "+ j);
                j++;
                // j voor de volgende lege plaats
            }
            
        }
        
        
        return meestGelachen;
    }
    
    public double extra(){
        double testloon = 0;
        int dagen = 0;
        for (int i = 0; i < schater.length; i++) {
        dagen = dagen + 1;
        testloon = testloon + loon;
            if (dagen <= 101 && dagen >= 150) {
                testloon = testloon /100*10;
        }   
            if (dagen <= 151 && dagen >= 199) {
                testloon = (testloon /100*10) + (testloon /100*15);
        } 
            if (dagen <= 200) {
                testloon = (testloon /100*10) + (testloon /100*15) + (testloon /100*20);
        } 
        }
      
        return testloon;
    }

    public int toonHardstGelachen() {
        //retutn een getal van 0 tot 364
        int meest = schater[0];
        int plaats = 0;
        for (int i = 0; i < schater.length; i++) {
            if (schater[i] > meest) {
                meest = schater[i];
                plaats = i;
            }
        }
        System.out.println(plaats);
        return plaats;
    }

    public void vulGewerkteDag(int dag) // dag is een nummer die overeenkomt met een weekdag
    {
        werkt[dag] = true;
    }

    public void vulSchaterIn(int dag, int decibels) {
        schater[dag] = decibels;
    }

    public void jaarloon() {
        int teller = 0;
        for (int i = 0; i < schater.length; i++) {
            if (schater[i] > 0) {
                teller++;
            }
        }
        System.out.println("jaarloon = " + (loon * teller));
    }

    public void berekenToeslag() {
        int teller = 0;
        int som = 0;
        for (int i = 0; i < schater.length; i++) {
            if (schater[i] > 0) {
                teller++;
                som += schater[i];
            }
        }
        System.out.println("bonus = " + (som / teller * 10));
    }

    public void drukAfGewerkteDagen() {
        for (int i = 0; i <= werkt.length; i++) {
            if (werkt[i] == true) {
                System.out.println("werkt op " + dagenWeek[i]);
            }
        }
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public int[] getSchater() {
        return schater;
    }

    public void setSchater(int[] schater) {
        this.schater = schater;
    }

    public boolean[] getWerkt() {
        return werkt;
    }

    public void setWerkt(boolean[] werkt) {
        this.werkt = werkt;
    }

    public double getLoon() {
        return loon;
    }

    public void setLoon(double loon) {
        this.loon = loon;
    }

}
