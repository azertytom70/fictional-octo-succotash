package array;

import javax.swing.JOptionPane;

public class Array {

    private double[] lijst = new double[5];

    public Array() {

        lijst[0] = 15;
        lijst[1] = 15;
        lijst[2] = 30;
        lijst[3] = 30;
        lijst[4] = 30;
    }

    public void drukAf() {
        for (int i = 0; i < lijst.length; i++) {
            System.out.println(lijst[i]);
        }
    }

    public void drukAfOmgekeerd() {
        for (int i = lijst.length - 1; i >= 0; i--) {
            System.out.println(lijst[i]);
        }
    }

    public void Som() {
        double som = 0;
        for (int i = 0; i < lijst.length; i++) {
            som = som + lijst[i];
        }
        System.out.println(" de som is " + som);
    }

    public double gemiddelde() {
        double som = 0;
        for (int i = 0; i < lijst.length; i++) {
            som = som + lijst[i];
        }
        double gemiddelde = (double) som / lijst.length;
        System.out.println("het gemiddelde is " + gemiddelde);
        return gemiddelde;
    }

    public void drukGetallenGroterTien() {
        for (int i = 0; i < lijst.length; i++) {
            if (lijst[i] >= 10) {
                System.out.println(lijst[i]);
            }
        }
    }

    public void vermenigvuldig() {
        double som = 1;
        for (int i = 0; i < lijst.length; i++) {
            if (lijst[i] > 0) {
                som *= lijst[i];
            }
        }
        System.out.println("als alles met elkaar vermenigvuldig is is jou uitkomst " + som);
    }

    public void vervang() {
        double gem = gemiddelde();
        for (int i = 0; i < lijst.length; i++) {
            lijst[i] = lijst[i] - gem;
            System.out.println(lijst[i]);
        }
    }

    public void zoekgetal() {
        double invoer = Double.parseDouble(JOptionPane.showInputDialog("Geef getal"));
        int teller = 0;
        for (int i = 0; i < 5; i++) {
            if (invoer == lijst[i]) {
                teller = teller + 1;
            }

        }
        System.out.println(teller);
    }

    public double grootste() {
        double bijhouden = lijst[4];
        double grootste = lijst[0];
        for (int i = 1; i < lijst.length; i++) {
            if (grootste <= lijst[i]) {
                grootste = lijst[i];
            }
        }
        return grootste;
    }

    public int plaatsgrootste() {
        double grootste = lijst[0];
        int plaats = 0;
        for (int i = 1; i < lijst.length; i++) {
            if (grootste <= lijst[i]) {
                grootste = lijst[i];
                plaats = i;
            }
        }
        return plaats;
    }

    public double komtMeesteVoor() {
        double[] getallen = new double[lijst.length];
        // in aantallen staan allemaal nullen: {0, 0, 0, 0, 0}
        int[] aantallen = new int [lijst.length];
        int plaatsVerschillende = 0;
        // eerst vrije plaats in getallen (daar waar het volgende verschillend getal moet kommen.)
        boolean gevonden = false;
        // het aantal getallen die staan in array met unieke getallen
        for (int i = 0; i < lijst.length; i++) {
            for (int j = 0; j < plaatsVerschillende && !gevonden; j++) {
                if (getallen[j] == lijst[i]) {
                    aantallen[j]++;
                    gevonden = true;
                }
            }
            // kan ook: if (gevonden == false) {
            if (!gevonden) {
                getallen[plaatsVerschillende] = lijst[i];
                aantallen[plaatsVerschillende]++;
                plaatsVerschillende++;
            }
            gevonden = false;
            
        }
        //het grootste aantal zoeken in aantallen
        double grootste = aantallen[0];
        int plaatsGrootste = 0;
        for (int i = 0; i < aantallen.length; i++) {
            if (aantallen[i] > grootste) {
                grootste = aantallen[i];
                plaatsGrootste = i;
            }
        }
//        for (int i = 0; i < getallen.length; i++) {
//            System.out.println(getallen[i] + "aantal: " + aantallen[i]);
//        }
        return getallen[plaatsGrootste];
    }

    public void laastePlaatsGrootste() {
        lijst[lijst.length - 1] = grootste();
    }

    public double kleinste() {
        double bijhouden = lijst[4];
        double kleinste = lijst[0];
        for (int i = 1; i < lijst.length; i++) {
            if (kleinste > lijst[i]) {
                kleinste = lijst[i];
            }
        }
        return kleinste;
    }

    public int plaatskleinste() {
        double kleinste = lijst[0];
        int plaats = 0;
        for (int i = 1; i < lijst.length; i++) {
            if (kleinste < lijst[i]) {
                kleinste = lijst[i];
                plaats = i;
            }
        }
        return plaats;
    }

    public void laastePlaatskleinste() {
        lijst[lijst.length - 1] = kleinste();
    }

    public void verwissel() {
        double grootste = grootste();
        double kleinste = kleinste();
        int plaatsklein = plaatskleinste();
        int plaatsgroot = plaatsgrootste();
        lijst[plaatsklein] = kleinste;
        lijst[plaatsgroot] = grootste;
    }

}
