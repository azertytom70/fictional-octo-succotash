package array;

public class TestArray {

    public static void main(String[] args) {
        Array a1 = new Array();
        System.out.println("meest voorkomend "+ a1.komtMeesteVoor());
//        a1.drukAf();
//        a1.drukAfOmgekeerd();
//        a1.Som();
//        a1.gemiddelde();
//        a1.drukGetallenGroterTien();
//        a1.vermenigvuldig();
//        a1.vervang();
//        a1.zoekgetal();
//        a1.grootste();
//        a1.drukAf();
//        a1.laastePlaatsGrootste();
//        a1.plaatsgrootste();
//        a1.verwissel();
//        a1.drukAf();
    }

}
