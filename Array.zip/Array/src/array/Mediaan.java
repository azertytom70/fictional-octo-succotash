package array;

import java.util.Arrays;

public class Mediaan {

    private double punten[] = {20, 4, 5, 15, 17,16};

    public Mediaan() {
    }
 // sort is static word schuins geschreven functie oproepen naam van klasse.staticnaam
    public double berekenMediaan() {
        Arrays.sort(punten);
        System.out.println(Arrays.toString(punten));
        if (punten.length % 2 == 0) { //even
            return (punten[punten.length / 2] + punten[punten.length / 2 -1]) /2 ; 
        } else //oneven
        {
           return punten[punten.length / 2];
        }
        
    }

    /*public void letsDoIt() {
        int[] array = {45, 12, 85, 32, 89, 39, 69, 44, 42, 1, 6, 8};
        int temp;
        for (int i = 1; i < array.length; i++) {
            for (int j = i; j > 0; j--) {
                if (array[j] < array[j - 1]) {
                    temp = array[j];
                    array[j] = array[j - 1];
                    array[j - 1] = temp;
                }
            }
        }
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }*/

    public double[] getArray() {
        return punten;
    }

    public void setArray(double[] array) {
        this.punten = punten;
    }

}
