package array;
public class testclown {

    public static void main(String[] args) {
        clown jefke = new clown("jefke joske",250);
        clown bob = new clown("Bob The Builder",10);
        jefke.vulGewerkteDag(0);
        jefke.vulGewerkteDag(3);
        jefke.vulGewerkteDag(4);
        jefke.vulGewerkteDag(5);
        jefke.vulGewerkteDag(6);
        
        /*for (int i = 0; i < 80; i++) {
            jefke.vulSchaterIn(i, 120);
           // jefke.jaarloon();
           // jefke.berekenToeslag();
           
        }*/
        // jefke.toonHardstGelachenMeer();  
       // jefke.toonHardstGelachen();
        //jefke.jaarloon();
        //jefke.berekenToeslag();
      /*  for (int i = 100; i < 200; i++) {
            jefke.vulSchaterIn(i, 90);
        }*/
        jefke.extra();
       // jefke.drukAfGewerkteDagen();
       // jefke.jaarloon();
      //  bob.jaarloon();
    }
    
}
