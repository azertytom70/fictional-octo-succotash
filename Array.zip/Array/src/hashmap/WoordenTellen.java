/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;
import java.util.HashMap;
/**
 *
 * @author tomge
 */
public class WoordenTellen {
    private HashMap<String, Integer>lijst = new HashMap<String, Integer>();
    public WoordenTellen() {
    }
    public void telWoorden(String zin){
        String woorden[]=zin.split(" ");
        for(String woord :  woorden){
            if(lijst.containsKey(zin)==true)
            {
                //eerst value ophalen
                int hoeveel = lijst.get(woord);
                hoeveel++;
                lijst.replace(woord, hoeveel);
            }
            else
            {
                lijst.put(woord, 1);
                //nieuw woord
            }
        }
    }
    public void printen(){
        for (String woord : lijst.keySet()) {
            System.out.println(woord + " " +lijst.get(woord));
        }
    }
    public HashMap<String, Integer> meestVoorkomendWoord(){
        HashMap<String, Integer>lijstMeest = new HashMap<String, Integer>();
        return lijstMeest;
    }
}
