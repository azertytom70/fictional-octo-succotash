/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;

import java.util.HashMap;

/**
 *
 * @author tomge
 */
public class Coderen {
    private HashMap<Character, Integer>secretmap = new HashMap<Character, Integer>();

    public void fillsecretMap(){
        secretmap.put('A', 1);
        secretmap.put('B', 2);
        secretmap.put('C', 3);
        secretmap.put('D', 4);
        secretmap.put('E', 5);
        secretmap.put('F', 6);
        secretmap.put('G', 7);
        secretmap.put('H', 8);
        secretmap.put('I', 9);
        secretmap.put('J', 10);
        secretmap.put('K', 11);
        secretmap.put('L', 12);
        secretmap.put('M', 13);
        secretmap.put('N', 14);
        secretmap.put('O', 15);
        secretmap.put('P', 16);
        secretmap.put('Q', 17);
        secretmap.put('R', 18);
        secretmap.put('S', 19);
        secretmap.put('T', 20);
        secretmap.put('U', 21);
        secretmap.put('V', 22);
        secretmap.put('W', 23);
        secretmap.put('X', 24);
        secretmap.put('Y', 25);
        secretmap.put('Z', 26);
    }
    
    public void print(){
        for (char teken : secretmap.keySet()) {
            int code =secretmap.get(teken);
            System.out.println(teken +" "+ code);
        }    
    }
    
    public String codeer(String zin){
        zin =zin.trim().toUpperCase();
        String gecodeerdezin = " ";
        for (int i = 0; i < zin.length(); i++) {
            char kar = zin.charAt(i);
            int code = secretmap.get(kar);
            gecodeerdezin +=" "+ code;
        }
        System.out.println(gecodeerdezin);
        return gecodeerdezin;

    }
    
    
public String Decodeer(String zin){
    String gedecodeerdezin = " ";
    String[] codeArray = zin.split(" ");
    
    for(String code :codeArray) {
        for(char teken : secretmap.keySet()){
            int c = secretmap.get(teken);
            if((c+"").equals(code)){
                gedecodeerdezin += teken;
            }
        }
    }
    return gedecodeerdezin;
}
    
}
