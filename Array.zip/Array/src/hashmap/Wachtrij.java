/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;
import java.util.HashMap;
/**
 *
 * @author tomge
 */
public class Wachtrij {
    private HashMap<String, String> lijst = new HashMap<String, String>();

    public Wachtrij() {
    }
    
    public void zetInWachtrij(String naam){
        lijst.put(naam, "Wachtend");
    }
    
        public void zetOpBediend(String naam){
       if(lijst.replace(naam, "Bediend")==null){
           System.out.println("naam komt niet voor in wachtrij");
       }
    }
        public void overzichtWachtnde(){
            int telWachtend = 0;
            int telBediende = 0;
            for (String naam : lijst.keySet()) {
                if(lijst.get(naam).equals("Wachtend")){
                    System.out.println(naam);
                    telWachtend++;
                }
                else{
                    telBediende++;
                }
            }
        }
}
