/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;
import java.util.HashMap;

/**
 *
 * @author tomge
 */
public class Hashmap {
    private HashMap<String, String> telLijst = new HashMap<>();
    
    public Hashmap() {
        telLijst.put("Gebruers", "123");
        telLijst.put("Janssens", "456");
        telLijst.put("something", "789");
    }
    
    public void zoekTelOp(String naam){
        if (telLijst.containsKey(naam)) {
            String tel = telLijst.get(naam);
            System.out.println(naam + " "+ tel);
        }
        else{
            System.out.println("naam staat er niet in");
        }
           
    }
    
    public boolean bestaatNaam(String naam){
        return telLijst.containsKey(naam);
    }
    
    public void veranderTel(String naam, String tel){
       String value = telLijst.replace(naam, tel);
        if (value==null) {
            System.out.println("deze naam komt niet vooe in het telefoonboek");
        }
    }
    
    public void alleNamen() {
        for (String naam: telLijst.keySet()) {
            System.out.println(naam);
        }
    }
    
    public void alleNamenMetTel(){
          for (String naam: telLijst.keySet()) {
            System.out.println(naam + " "+ telLijst.get(naam));
        }
    }
}
