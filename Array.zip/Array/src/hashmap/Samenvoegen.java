/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;

import java.util.HashMap;

/**
 *
 * @author tomge
 */
    public class Samenvoegen {

    private HashMap<String, String> map1 = new HashMap<>();
    private HashMap<String, String> map2 = new HashMap<>();
    private HashMap<String, String> samen = new HashMap<>();

    public void Samenvoegen() {
        map1.put("a", "b");
        map2.put("b", "c");
        //wordt in samen ("a", "c")
        //
        map1.put("d", "e");
        map2.put("e", "f");
        //wordt in samen ("d", "f")
        map1.put("g", "h");
        map2.put("i", "j");
        //wordt geen paar in samen want "h" is niet gelijk aan "i"
    }
    
 public void Samengevoegd(){
     for(String teken : map2.keySet()){
         for(String teken2 : map1.keySet()){
             if(teken.equals(map1.get(teken2))){
                 samen.put(teken2, map2.get(teken));
             }
         }
     }
 }
 
   public void print(){
        for (String teken : samen.keySet()) {
            String code =samen.get(teken);
            System.out.println(teken +" "+ code);
        }    
    }


}
