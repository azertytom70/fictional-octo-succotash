/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmap;

/**
 *
 * @author tomge
 */
public class TelefoonTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // Hashmap t1 =new Hashmap();
        //t1.zoekTelOp("Gebruers");
       // t1.bestaatNaam("Gebrues");
       // t1.veranderTel("get", "452");
       // t1.alleNamen();
      // Coderen c1 = new Coderen();
   //    c1.fillsecretMap();
       //c1.print();
       //c1.codeer("tom");
     //  c1.Decodeer("tom");
     Samenvoegen s1 = new Samenvoegen();
     s1.Samenvoegen();
     s1.Samengevoegd();
     s1.print();
    }
    
}
