package TweeDimensionaleArray;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class tienoptien {

    private int arr[][]
            = {
                {10, 12, 12, 45, 45},
                {1, 2, 3, 4, 5},
                {6, 7, 8, 9, 10},
                {11, 12, 13, 14, 15},
                {16, 17, 18, 19, 20}, // eerste [] is altijd rij 2de [] is altijd kolom
            };
    private ArrayList<Positie> c = new ArrayList<>();

    public tienoptien() {
    }

    public ArrayList<Positie> waarZitHetGrootste() {
        int voorlopigGrootste = arr[0][0];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (arr[i][j] > voorlopigGrootste) {
                    voorlopigGrootste = arr[i][j];
                }

            }
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (arr[i][j] == voorlopigGrootste) {
//                    System.out.println("plaats : rij " + i+ " kolom "+j); 
                    c.add(new Positie(i, j));
                }

            }
        }
        System.out.println(voorlopigGrootste);
        return c;
    }

    public void moveup() {
        int arr2[][] = arr.clone();
        for (int i = 0; i < arr.length - 1; i++) {
            arr[i] = arr[i + 1];
            /*
            eerste keer = arr[0]= arr[1]
            tweede keer = arr[1]= arr[2]
            derde keer = arr[2]= arr[3]
            vierde keer = arr[3]= arr[4]
            gebruik je 1 dimensie, dan heb je een volledige rij
             */
        }
        arr[arr.length - 1] = arr2[0];// omdat de 1st rij overschreven is gebruik je de kopie eerste rij
    }
public void moveUpAantal(int aantal) {

        for (int i = 0; i < aantal; i++) {
            moveup();
        }
    }


    public void moveleft() {
int arr2[] = new int[5];
        for (int i = 0; i < 5; i++) {
            arr2[i] = arr[i][0];
        }
        for (int j = 0; j < arr.length-1; j++) { //kolommen
            //eerste, tweede, derde en vierde kolom
            //ondertsaande for loop kopieert 1 kolom
            for(int i = 0; i < arr.length; i++){
                arr[i][j] = arr[i][j+1];
            }
        }
//        kolom 0 naar 4
        for(int i = 0; i < arr2.length-1; i++){
                arr[i][arr.length-1] = arr2[i];
        }
    }
    
    public void drukafpijl(){
        int arr2[][] = arr.clone();
        int nummer = 0;
        int nummer1 = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (j == nummer) {
                    System.out.print(arr[i][j] + "\t");
                    nummer++;
                }
                
            }
             System.out.println(" ");
        }
    }
    
        public void moveleft2() {
        int arr2[][] = new int[5][5];
        for (int j = 0; j < arr.length-1; j++) { 
            for(int i = 0; i < arr.length; i++){
                arr[i][j] = arr[i][j+1];
            }                 

        }
        for (int j = 0; j < arr.length-1; j++) { //kolommen
            //eerste, tweede, derde en vierde kolom
            //ondertsaande for loop kopieert 1 kolom
            for(int i = 0; i < arr.length; i++){
                arr[i][j] = arr[i][j+1];
            }
        }
//        kolom 0 naar 4
        for(int i = 0; i < arr.length-1; i++){
                arr[i][arr.length-1] = arr2[i][0];
        }
    }
        public void moveright() {
        int arr2[][] = arr.clone();
        for (int i = arr.length - 1; i == 0; i++) {
            for (int j = 0; j < arr.length - 1; j++) {
                arr[i][j] = arr[i][j + 1];
            }
        }
        arr[0][arr.length - 1] = arr2[0][0];
    }

//       public ArrayList<Positie> keerom() {
//        int voorlopigGrootste = arr[0][0];
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = 0; j < arr.length; j++) {
//                if (arr[i][j] > voorlopigGrootste) {
//                    voorlopigGrootste = arr[i][j];
//                }
//
//            }
//        }
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = 0; j < arr.length; j++) {
//                if (arr[i][j] == voorlopigGrootste) {
////                    System.out.println("plaats : rij " + i+ " kolom "+j); 
//                    c.add(new Positie(i, j));
//                }
//
//            }
//        }
////        System.out.println(voorlopigGrootste);
//        return c;
//    }
    public void drukaf() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println(" ");
        }
    }

    public void kopieer() {
        int arr2[][] = arr.clone();
        System.arraycopy(arr, 0, arr2, 0, arr.length);

    }
}
