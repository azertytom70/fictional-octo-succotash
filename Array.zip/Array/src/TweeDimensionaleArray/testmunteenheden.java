
package TweeDimensionaleArray;

import TweeDimensionaleArray.munteenheden;

public class testmunteenheden {
    public static void main(String[] args) {
        munteenheden m1 = new munteenheden();
        m1.wisselGrootNaarKlein();
//        System.out.println();
//        m1.wisselKleinNaarGroot();
    }
    
}
