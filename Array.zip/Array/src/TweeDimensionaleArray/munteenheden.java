package TweeDimensionaleArray;

import javax.swing.JOptionPane;

public class munteenheden {

    private int[] munten = {1, 2, 5, 10, 20, 50};
    private int[] munten2 = {50, 20, 10, 5, 2, 1};

    public munteenheden() {

    }

    public void wisselKleinNaarGroot() {
        int bedrag = Integer.parseInt(JOptionPane.showInputDialog("welk bedrag wil je wisselen")); 
        for (int i = munten.length -1; i >= 0; i--) {
            int aantal = bedrag / munten[i];
            int rest = bedrag % munten[i];
            String[] output = new String[6];
            System.out.println(output[i] = munten[i] + " : " + aantal);
            bedrag = rest;
        }

    }

    public void wisselGrootNaarKlein() {
        int bedrag = Integer.parseInt(JOptionPane.showInputDialog("welk bedrag wil je wisselen")); 
        for (int i = 0; i < munten2.length; i++) {
            int aantal = bedrag / munten2[i];
            int rest = bedrag % munten2[i];
            String[] output = new String[6];
            System.out.println(output[i] = munten2[i] + " : " + aantal);
            bedrag = rest;
        }
    }
}
