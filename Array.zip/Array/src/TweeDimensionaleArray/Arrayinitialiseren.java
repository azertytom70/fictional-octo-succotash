package TweeDimensionaleArray;

public class Arrayinitialiseren {

    private int[][] Lijst = {{12, 10, 11}, {5, 14, 9}, {10, 12, 12}, {13, 14, 10}, {10, 11, 21}};

    public Arrayinitialiseren() {
    }
// i is rijen en j zijn jouw kollommen

    public void drukAf() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print("\t" + Lijst[i][j]);
            }
            System.out.println();
        }
    }

    public void som() {
        int som = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                som +=  Lijst[i][j];

                }
            }
            System.out.println("som =" + som);
        }
    
        public void advancesom() {
        int som = 0;
        int advance = 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                som +=  Lijst[i][j];
                advance +=  Lijst[i][j];
                if (j == 3) {
                    System.out.println("test"+ advance);
                    advance = 0;
                }
                }
            }
            System.out.println("som =" + som);
        }

    public void kleinste() {
        double kleinste = Lijst [0][0] ;
                for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 3; j++) {
                if (kleinste > Lijst[i][j]) {
                    kleinste = Lijst[i][j];
                }
            }  
        }
                System.out.println("de kleinste is " + kleinste);
    }
}
