/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TweeDimensionaleArray;

import TweeDimensionaleArray.array3op3;

/**
 *
 * @author sydney
 */
public class testarray3op3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        array3op3 a = new array3op3();
        //a.printOpPaneel();
        a.vervangDiagonaal();
        //a.vervangEven();
    }
    
}
