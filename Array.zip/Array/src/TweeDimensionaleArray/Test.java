package TweeDimensionaleArray;

import TweeDimensionaleArray.Arrayinitialiseren;

public class Test {
	public static void main(String[] args) {
		Arrayinitialiseren a1 = new Arrayinitialiseren();
		a1.drukAf();
                a1.som();
                a1.kleinste();
               // a1.advancesom();
	}
}

