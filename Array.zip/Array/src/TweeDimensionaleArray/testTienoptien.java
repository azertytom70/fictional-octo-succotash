package TweeDimensionaleArray;

import TweeDimensionaleArray.tienoptien;

/**
 *
 * @author sydney
 */
public class testTienoptien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        tienoptien o1 = new tienoptien();
        o1.drukafpijl();
//        o1.waarZitHetGrootste();
//        o1.drukaf();
//        o1.moveup();
//        o1.drukaf();
//        o1.moveUpAantal(2);
//                o1.drukaf();
//System.out.println("");
//        o1.moveleft2();
//        o1.drukaf();
//        System.out.println("");
//                o1.kopieer();
//        o1.drukaf();
//        o1.moveright();
//        o1.drukaf();
    }
    
}
