/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TweeDimensionaleArray;

import javax.swing.JOptionPane;

/**
 *
 * @author sydney
 */
public class array3op3 {

    int[][] matrix = new int[3][3];

    public array3op3() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matrix[i][j] = Integer.parseInt(JOptionPane.showInputDialog("geef getal in"));
            }
        }

    }

    public void printOpPaneel() {
        String s = "";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                s = s + matrix[i][j] + "    ";
            }
            s = s + "\n";
        }
        JOptionPane.showMessageDialog(null, s);
    }

    public void vervangEven() {
        String s = "";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (matrix[i][j] % 2 == 0) {
                    matrix[i][j] = 0;
                }
                s = s + matrix[i][j] + "    ";

            }
            s = s + "\n";
        }
        JOptionPane.showMessageDialog(null, s);
    }

    public void vervangDiagonaal() {
        String s = "";
             for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                //
                if (i == j || i + j == matrix.length-1) { // rij == kolom of rij plus kolom = aantal elementen per rij/kolom
                    matrix[i][j] = 0;
                }
                s = s + matrix[i][j] + "    ";
            }
            s = s + "\n";
        }
        JOptionPane.showMessageDialog(null, s);

    }

}
